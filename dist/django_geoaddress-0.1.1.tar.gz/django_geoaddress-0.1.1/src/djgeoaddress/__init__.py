"""Django GeoAddress - Address verification and geocoding for Django."""

from __future__ import annotations

__version__ = "0.1.0"

default_app_config = "djgeoaddress.apps.DjGeoAddressConfig"
